#PEDIDO
import mysql.connector
from conectar import connect_db

def read_pedido():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM pedido")
            resultados = cursor.fetchall()
            return {'status': 'sucesso', 'dados': resultados}
        except mysql.connector.Error as err:
            return {'status': 'erro', 'mensagem': f"erro ao listar pedidos: {err}"}
        finally:
            cursor.close()
            conn.close()

#notificacao

def read_notificacao():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM notificacao")
            resultados = cursor.fetchall()
            return {'status': 'sucesso', 'dados': resultados}
        except mysql.connector.Error as err:
            return {'status': 'erro', 'mensagem': f"erro ao listar notificações: {err}"}
        finally:
            cursor.close()
            conn.close()
#consulta de fornecedores
def read_fornecedores():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT*FROM fornecedor")
            resultados=cursor.fetchall()
            return{'status':'Sucesso!','mensagem':resultados}
        except mysql.connector.Error as err:
            return{'status':'Erro','mensagem':f'Erro ao listar fornecedores {err}'}
        finally:
            cursor.close()
            conn.close()

#clientes
def read_cliente():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute ("SELECT * FROM cliente")
            resultados = cursor.fetchall
            return {'status':'sucesso','dados':resultados}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao listar clientes {err}"}
        finally:
            cursor.close()
            conn.close()
#funcionarios
def read_funcionario():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute ("SELECT * FROM funcionario")
            resultados = cursor.fetchall
            return {'status':'sucesso','dados':resultados}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao listar funcionarios {err}"}
        finally:
            cursor.close()
            conn.close()
#produto
def read_produto():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute ("SELECT * FROM produto")
            resultados = cursor.fetchall
            return {'status':'sucesso','dados':resultados}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao listar produto {err}"}
        finally:
            cursor.close()
            conn.close()
#mapa
def read_plantadeposito():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute ("SELECT * FROM mostraplanta")
            resultados = cursor.fetchall
            return {'status':'sucesso','dados':resultados}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao listar planta {err}"}
        finally:
            cursor.close()
            conn.close()
#movimentação
def read_movimento():
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute ("SELECT * FROM movimentacao")
            resultados = cursor.fetchall
            return {'status':'sucesso','dados':resultados}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao listar movimentacao {err}"}
        finally:
            cursor.close()
            conn.close()
