from flask import Flask, request, jsonify
from inserir import insert_pedido #vai pegando os imports das outras pastas
from consultar import read_pedido
from atualizar import update_pedido
from deletar import delete_pedido
from inserir import insert_notificacao 
from consultar import read_notificacao
from atualizar import update_notificacao
from deletar import delete_notificacao
from inserir import insert_fornecedores
from consultar import read_fornecedores
from atualizar import update_fornecedor
from deletar import delete_fornecedor
from inserir import insert_cliente, insert_empilhadeira, insert_funcionario, insert_login, insert_produto, insert_plantadeposito, insert_movimento
from consultar import read_cliente, read_funcionario, read_produto, read_plantadeposito, read_movimento
from atualizar import update_cliente, update_funcionario, update_produto, update_plantadeposito, update_movimento
from deletar import delete_cliente, delete_funcionario, delete_produto



app = Flask(__name__)

######## rota de clientes - início #######

#rota para criacao de novos clientes
@app.route('/cliente', methods =['POST'])
def criar_cliente():
    dados = request.json
    print("API", dados)
    resposta = insert_cliente(dados)
    return jsonify(resposta), 201 if resposta.get('status') == 'sucesso' else 400

#rota para listar clientes
@app.route('/cliente', methods =['GET'])
def listar_clientes():
    resposta = read_cliente()
    return jsonify(resposta)


#rota para atualizar cliente
@app.route('/cliente/<int:cliente_id>', methods =['PUT'])
def atualizar_cliente(cliente_id):
    dados = request.json
    dados['cliente_id'] = cliente_id
    resposta = update_cliente(dados)
    return jsonify(resposta),200 if resposta.get('status') == 'sucesso' else 400

#rota para excluir cliente
@app.route('/cliente/<int:cliente_id>', methods = ['DELETE'])
def excluir_cliente(cliente_id):
    resposta = delete_cliente(cliente_id)
    return jsonify(resposta)

########## rota empilhadeira-INICIO ###########
# rota para criacao de empilhadeira
empilhadeira = []
@app.route("/buscaempilhadeira/<int:indice>", methods=["GET"]) 

def buscar_empilhadeira(indice): 

    if indice < len(empilhadeira): 
        return jsonify(empilhadeira[indice]) 
    return jsonify({"erro":"empilhadeira não encontrada"}), 404 


@app.route("/adicionarempilhadeira",methods=["POST"]) 

def adicionar_empilhadeira(): 

    id_empilhadeira = request.get_json() 
    resposta_emp= insert_empilhadeira (id_empilhadeira) 
    return jsonify({"mensagem":"Empilhadeira adicionada com sucesso!"}), 201 


############ rota funcionario- INICIO#########
funcionarios = []

@app.route("/funcionarios", methods=["GET"])
def put_funcionarios():
    return jsonify(read_funcionario)

@app.route("/funcionarios", methods=["POST"])
def post_funcionarios():
    dados = request.get_json()
    respsta_func= insert_funcionario.append(dados)
    return jsonify({"mensagem":"Funcionario adicionado com sucesso!"}), 201 

@app.route("/funcionarios/<int:indice>", methods=["PUT"])
def put_funcionarios(indice):
    dados = request.get_json()
    if indice < len(funcionarios):
        update_funcionario[indice] = dados
        return {"valido": True, "aviso": "atualizado!"}

@app.route('/funcionario/<int:funcionario_id>', methods = ['DELETE'])
def excluir_funcionario(funcionario_id):
    resposta = delete_funcionario(funcionario_id)
    return jsonify(resposta)

########## rota de login - INICIO##########

@app.route('/login', methods =['POST'])
def criar_login():
    dados = request.json
    print("API", dados)
    resposta = insert_login(dados)
    return jsonify(resposta), 201 if resposta.get('status') == 'sucesso' else 400

######## rota de produto - INICIO########
produto=[]

@app.route("/produto", methods=["GET"])
def listar_produto():
    return jsonify(read_produto)

# cadastro produtos
@app.route("/produto", methods=["POST"])
def adicionar_produto():
    novo_produto = request.get_json()
    resposta_produto =insert_produto.append(novo_produto)
    return jsonify(resposta_produto), 201 if resposta_produto.get('status') == 'sucesso' else 400

# atualizar produtos pelo indice
@app.route("/produto/<int:indice>", methods=["PUT"])
def atualizar_produtos(indice):
    if indice < len(produto):
        dados=request.get_json()
        resposta_produtos=update_produto[indice]. produto(dados)
        return jsonify({"mensagem":"produto  atualizado com sucesso"})
    return jsonify({"erro":"produto não encontrado"}), 404

# deletar produtod pelo indice
@app.route("/produto/<int:indice>", methods=["DELETE"])
def deletar_produto(indice):
    if indice < len(produto):
        resposta_produto= delete_produto.pop(indice)
        return jsonify({"mensagem":"Produto não encontrado"}), 404

################# rota mapa/planta deposito - INICIO##############

plantadeposito = []

@app.route("/mostraplanta", methods=["GET"])
def listar_plantadeposito():
    return jsonify(read_plantadeposito)

@app.route("/atualizarplanta/<int:indice>", methods=["PUT"])
def atualizar_plantadeposito(indice):
    if indice < len(plantadeposito):
        dados = request.get_json()
        resposta =update_plantadeposito[indice].update(dados)
        return jsonify({"mensagem":"planta atualizado com sucesso!"}), 404

@app.route("/criarplanta/<int:indice>", methods=["POST"])
def adicionar_plantadeposito(indice):
    if indice < len(plantadeposito):
        dados = request.get_json()
        inserir_plantadeposito = dados
        return jsonify({"mensagem":"planta adicionada com sucesso!"}), 404

############## rota movimento - INICIO #############

@app.route('/movimento', methods =['POST'])
def criar_movimento():
    dados = request.json
    print("API", dados)
    resposta = insert_movimento (dados)
    return jsonify(resposta), 201 if resposta.get('status') == 'sucesso' else 400

#rota para listar clientes
@app.route('/movimento', methods =['GET'])
def listar_movimento():
    resposta = read_movimento ()
    return jsonify(resposta)


#rota para atualizar cliente
@app.route('/movimento/<int:movimento_id>', methods =['PUT'])
def atualizar_movimento(movimento_id):
    dados = request.json
    dados['movimento_id'] = movimento_id
    resposta = update_movimento(dados)
    return jsonify(resposta),200 if resposta.get('status') == 'sucesso' else 400

########## ROTA DE PEDIDOS - INICIO ##########

#Rota para criação de novos pedidos
@app.route('/pedido', methods=['POST'])
def criar_pedido():
    dados = request.jsonprint("API", dados)
    resposta = insert_pedido(dados)
    return jsonify(resposta), 201 if resposta.get('status') == 'sucesso' else 400

#Rota pra listar os pedidos
@app.route('/pedido', methods=['GET'])
def listar_pedido():
    resposta = read_pedido
    return jsonify(resposta)

#Rota pra atualizar pedido
@app.route('/pedido/<int;pedido_id>', methods=['PUT'])
def atualizar_pedido(pedido_id):
    dados = request.json
    dados['pedido_id'] = pedido_id
    resposta = update_pedido(dados)
    return jsonify(resposta), 200 if resposta.get('status') == 'sucesso' else 400

#Rota pra excluir pedido
@app.route('/pedido/<int;pedido_id>', methods=['DELETE'])
def excluir_pedido(pedido_id):
    resposta = delete_pedido(pedido_id)
    return jsonify(resposta)

########## FIM DA ROTA DE PEDIDOS ##########

#Rota para criação de novos notificacaos
@app.route('/notificacao', methods=['POST'])
def criar_notificacao():
    dados = request.jsonprint("API", dados)
    resposta = insert_notificacao(dados)
    return jsonify(resposta), 201 if resposta.get('status') == 'sucesso' else 400

#Rota pra listar os notificacaos
@app.route('/notificacao', methods=['GET'])
def listar_notificacao():
    resposta = read_notificacao
    return jsonify(resposta)

#Rota pra atualizar notificacao
@app.route('/notificacao/<int;notificacao_id>', methods=['PUT'])
def atualizar_notificacao(notificacao_id):
    dados = request.json
    dados['notificacao_id'] = notificacao_id
    resposta = update_notificacao(dados)
    return jsonify(resposta), 200 if resposta.get('status') == 'sucesso' else 400

#Rota pra excluir notificacao
@app.route('/notificacao/<int;notificacao_id>', methods=['DELETE'])
def excluir_notificacao(notificacao_id):
    resposta = delete_notificacao(notificacao_id)
    return jsonify(resposta)

########## FIM DA ROTA DE notificacao ##########

############ Rota de Fornecedores ##############
@app.route('/fornecedores', methods=['POST'])
def add_fornecedor():
    dados = request.json
    print("API", dados)
    resposta = insert_fornecedores(dados)
    return jsonify(resposta), 201 if resposta.get('status') == 'sucesso' else 400

#rota puxar
@app.route('/fornecedores', methods=['GET'])
def listagem_fornecedor():
    resposta = read_fornecedores()
    return jsonify(resposta)

#rota atualizar
@app.route('/fornecedores/<int:id_fornecedor>', methods= ['PUT'])
def atualizar_fornecedores(id_fornecedor):
    dados= request.json
    dados['id_fornecedor'] = id_fornecedor
    resposta = update_fornecedor(dados)
    return jsonify(resposta), 200 if resposta.get('status') == 'sucesso' else 400

#rota excluir
@app.route('/fornecedores/<int:id_fornecedor>', methods= ['DELETE'])
def excluir_fornecedores(id_fornecedor):
    resposta = delete_fornecedor(id_fornecedor)
    return jsonify(resposta)


if __name__=="__main__":
    app.run(debug = True)