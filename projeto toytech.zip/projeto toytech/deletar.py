#PEDIDO
import mysql.connector
from conectar import connect_db

def delete_pedido(pedido_id):
    conn = connect_db()
    if conn:
        try:
            cursor = conn.cursor()
            sql = "DELETE FROM Cliente WHERE pedido_id = %s"
            cursor.execute(sql(pedido_id,))
            conn.commit()
            return{'status': 'sucesso', "mensagem": f"pedido{pedido_id} excluido com sucesso."}
        except mysql.connector.Error as err:
            return{'status': 'erro', 'mensagem': f"erro ao excluir cliente: {err}"}
        finally:
            cursor.close()
            conn.close()

#notificação

def delete_notificacao(notificacao_id):
    conn = connect_db()
    if conn:
        try:
            cursor = conn.cursor()
            sql = "DELETE FROM Cliente WHERE notificacao_id = %s"
            cursor.execute(sql(notificacao_id,))
            conn.commit()
            return{'status': 'sucesso', "mensagem": f"notificacao{notificacao_id} excluido com sucesso."}
        except mysql.connector.Error as err:
            return{'status': 'erro', 'mensagem': f"erro ao excluir notificação: {err}"}
        finally:
            cursor.close()
            conn.close()
            
#deletar fornecedor
def delete_fornecedor(fornecedor_id):
    conn = connect_db()
    if conn:
        try:
            cursor=conn.cursor()
            sql = 'DELETE FROM fornecedor WHERE fornecedor_id = %s'
            cursor.execute(sql,(fornecedor_id,))
            conn.commit()
            return {'status':'Sucesso!','mensagem':'fornecedor excluído'}
        except mysql.connector.Error as err:
            return{'status':'Erro!','mensagem':f'falha ao excluir fornecedor {err}'}
        finally:
            cursor.close()
            conn.close()

#deletar cliente
def delete_cliente(cliente_id):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            sql="DELETE FROM cliente WHERE cliente_id = %s"
            cursor.execute(sql, (cliente_id,))
            conn.commit()
            return {'status':'sucesso','mensagem':f"Cliente {cliente_id} deletado"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao excluir cliente {err}"}
        finally:
            cursor.close()
            conn.close()

# deletar funcionario
def delete_funcionario(funcionario_id):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            sql="DELETE FROM funcionario WHERE funcionario_id = %s"
            cursor.execute(sql, (funcionario_id,))
            conn.commit()
            return {'status':'sucesso','mensagem':f"Funcionario {funcionario_id} deletado"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao excluir funcionario {err}"}
        finally:
            cursor.close()
            conn.close()
#deletar produto
def delete_produto(produto_id):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            sql="DELETE FROM produto WHERE produto_id = %s"
            cursor.execute(sql, (produto_id,))
            conn.commit()
            return {'status':'sucesso','mensagem':f"Produto {produto_id} deletado"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao excluir produto {err}"}
        finally:
            cursor.close()
            conn.close()