#pedido
import mysql.connector
from conectar import connect_db

#atualizar cliente
def update_cliente(dados):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            #alterar telefone
            sql="UPDATE cliente SET tel = %s WHERE cliente_id = %s"
            values = (dados['tel'], dados['cliente_id'])
            cursor.execute(sql,values)
            conn.commit()
            #alterar cep
            sql="UPDATE cliente SET cep = %s WHERE cliente_id = %s"
            values = (dados['cep'], dados['cliente_id'])
            cursor.execute(sql,values)
            conn.commit()
            #alterar email
            sql="UPDATE cliente SET email = %s WHERE cliente_id = %s"
            values = (dados['email'], dados['cliente_id'])
            cursor.execute(sql,values)
            conn.commit()
            #alterarb senha
            sql="UPDATE cliente SET senha = %s WHERE cliente_id = %s"
            values = (dados['senha'], dados['cliente_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':f"Cliente{dados['cliente_id']} atualizado com sucesso"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao atualizar cliente {err}"}
        finally:
            cursor.close()
            conn.close()



#atualizar funcionario
def update_funcionario(dados_func):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            #atualizar email do funcionario
            sql="UPDATE funcionario SET email = %s WHERE funcionario_id = %s"
            values = (dados_func['email'], dados_func['funcionario_id'])
            cursor.execute(sql,values)
            conn.commit()
            #atualizar senha do funcionario
            sql="UPDATE funcionario SET senha = %s WHERE funcionario_id = %s"
            values = (dados_func['senha'], dados_func['funcionario_id'])
            cursor.execute(sql,values)
            conn.commit()
            #atualizar cargo do funcionario
            sql="UPDATE funcionario SET cargo = %s WHERE funcionario_id = %s"
            values = (dados_func['cargo'], dados_func['funcionario_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':f"Funcionario{dados_func['funcionario_id']} atualizado com sucesso"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao atualizar funcionario {err}"}
        finally:
            cursor.close()
            conn.close()

# atualizar produtos
def update_produto(dados):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            #alterar telefone
            sql="UPDATE produto SET enderecamento = %s WHERE produto_id = %s"
            values = (dados['enderecamento'], dados['produto_id'])
            cursor.execute(sql,values)
            conn.commit()
            #alterar cep
            sql="UPDATE produto SET descricao = %s WHERE produto_id = %s"
            values = (dados['descricao'], dados['produto_id'])
            cursor.execute(sql,values)
            conn.commit()
            #alterar email
            sql="UPDATE produto SET preco_venda = %s WHERE produto_id = %s"
            values = (dados['preco_venda'], dados['produto_id'])
            cursor.execute(sql,values)
            conn.commit()
            #alterarb senha
            sql="UPDATE produto SET preco_custo = %s WHERE produto_id = %s"
            values = (dados['preco_custo'], dados['produto_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':f"Produto {dados['produto_id']} atualizado com sucesso"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao atualizar produto {err}"}
        finally:
            cursor.close()
            conn.close()

# atualizar planta
def update_plantadeposito(dados):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            sql="UPDATE atualizarplanta SET imagem= %s WHERE plantadeposito_id = %s"
            values = (dados['imagem'], dados['plantadeposito_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':f"Planta {dados['plantadeposito_id']} atualizado com sucesso"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao atualizar planta {err}"}
        finally:
            cursor.close()
            conn.close()

# atualizar movimentacao 
def update_movimento(dados):
    conn = connect_db
    if conn:
        try:
            cursor = conn.cursor()
            sql="UPDATE movimentacao SET dados = %s WHERE movimentacao_id = %s"
            values = (dados['dados'], dados['movimentacao_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':f"Movimentação {dados['movimentacao_id']} atualizada com sucesso"}
        except mysql.connector.Error as err:
            return {'status':'erro','mensagem':f"Erro ao atualizar movimentação {err}"}
        finally:
            cursor.close()
            conn.close()


#pedido
def update_pedido(pedido):
    conn = connect_db()
    if conn:
        try:
            cursor = conn.cursor()
            sql = "UPDATE pedido SET pagmento = %s WHERE pedido_id = %s"
            values = (pedido['pagmento'], pedido['pedido_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status': 'sucesso', 'mensagem': f"pedido {pedido['pedido_id']} atualizado com sucesso."}
        except mysql.connector.Error as err:
            return {'status': 'erro', 'mensagem': f"erro ao atualizar pedidos: {err}"}
        finally:
            cursor.close()
            conn.close()

#notificação

def update_notificacoes(notificacao):
    conn = connect_db()
    if conn:
        try:
            cursor = conn.cursor()
            sql = "UPDATE notificacao SET sobre = %s WHERE notificacao_id = %s"
            values = (notificacao['sobre'], notificacao['notificacao_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status': 'sucesso', 'mensagem': f"notificacao {notificacao['notificacao_id']} atualizado com sucesso."}
        except mysql.connector.Error as err:
            return {'status': 'erro', 'mensagem': f"erro ao atualizar notificações: {err}"}
        finally:
            cursor.close()
            conn.close()
#fornecedor
def update_fornecedor(fornecedor):
    conn = connect_db()
    if conn:
        try:
            cursor=conn.cursor()
            sql='UPDATE fornecedor SET fornecedor_cnpj = %s, fornecedor_nome = %s WHERE fornecedor_id = %s'
            values = (fornecedor['fornecedor_cnpj'],fornecedor['fornecedor_nome'],fornecedor['fornecedor_id'])
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'Sucesso!','mensagem':'Fornecedor Atualizado!'}
        except mysql.connector.Error as err:
            return{'status':'Erro!','mensagem':f'não foi possivel atualizar {err}'}
        finally:
            cursor.close()
            conn.close()