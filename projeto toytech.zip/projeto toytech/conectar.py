#PEDIDO
import mysql.connector
def connet_db():
    try:
        connection = mysql.connector.connect(
            host="toytech_db",
            user="root",
            password="",
            database="toytech_db"
        )
        return connection
    except mysql.connector.Error as err:
        print(f"erro ao conectar ao banco de dados: {err}")
        return None
    
#notificações
import mysql.connector
def connect_db():
    try:
        connection = mysql.connector.connect (
            host = "toytech_db",
            user = "root",
            password = "",
            database = "toytech_db"
        )
        return connection
    except mysql.connector.Error as err:
        print(f"erro ao conectar ao banco de dados: {err}")
        return None