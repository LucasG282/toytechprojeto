

import mysql.connector
from conectar import connect_db

# inserir cadastro de cliente

def insert_cliente(dados):
    conn = connect_db
    print("conexao: ", conn)
    
    if conn:
        try:
            cursor = conn.cursor()
            sql="INSERT INTO cliente (nome, email, senha, cnpj, tel, cep) VALUES (%s, %s, %s, %s, %s, %s)"
            values = (dados['nome'], dados['email'], dados['senha'], dados['cnpj'], dados['tel'], dados['cep'])
            print (values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':'Cliente cadastrado com sucesso'}
        except mysql.connector.Error as err:
            print("erro",err)
            return {'status':'erro','mensagem':f"Erro ao cadastrar cliente {err}"}
        finally:
            cursor.close()
            conn.close()

#inserir cadastro de empilhadeira

def insert_empilhadeira(dados_empilhadeira):
    conn = connect_db
    print("conexao: ", conn)
    
    if conn:
        try:
            cursor = conn.cursor()
            sql="INSERT INTO empilhadeira (nome) VALUES (%s)"
            values = (dados_empilhadeira['nome'])
            print (values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':'Empilhadeira cadastrada com sucesso'}
        except mysql.connector.Error as err:
            print("erro",err)
            return {'status':'erro','mensagem':f"Erro ao cadastrar empilhadeira {err}"}
        finally:
            cursor.close()
            conn.close()

# inserir cadastro de funcionario
def insert_funcionario(dados_func):
    conn = connect_db
    print("conexao: ", conn)
    
    if conn:
        try:
            cursor = conn.cursor()
            sql="INSERT INTO funcionario (nome, senha, email, cargo) VALUES (%s, %s, %s, %s)"
            values = (dados_func['nome'], dados_func['senha'], dados_func['email'], dados_func['cargo'])
            print (values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':'Funcionario cadastrado com sucesso'}
        except mysql.connector.Error as err:
            print("erro",err)
            return {'status':'erro','mensagem':f"Erro ao cadastrar funcionario {err}"}
        finally:
            cursor.close()
            conn.close()

#inserir cadastro de login
def insert_login(dados):
    conn = connect_db
    print("conexao: ", conn)
    
    if conn:
        try:
            cursor = conn.cursor()
            sql="INSERT INTO login (email, senha) VALUES (%s, %s)"
            values = ( dados['email'], dados['senha'])
            print (values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':'Login cadastrado com sucesso'}
        except mysql.connector.Error as err:
            print("erro",err)
            return {'status':'erro','mensagem':f"Erro ao cadastrar login {err}"}
        finally:
            cursor.close()
            conn.close()

#inserir cadastro de produto
def insert_produto(dados):
    conn = connect_db
    print("conexao: ", conn)
    
    if conn:
        try:
            cursor = conn.cursor()
            sql="INSERT INTO produto (nome, descricao, enderecamento, reconhecimento_imagem, preco_custo, preco_venda) VALUES (%s, %s,%s, %s,%s, %s)"
            values = ( dados['nome'], dados['descricao'],dados['enderecamento'], dados['reconhecimento_imagem'], dados['preco_custo'], dados['preco_venda'])
            print (values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':'Produto cadastrado com sucesso'}
        except mysql.connector.Error as err:
            print("erro",err)
            return {'status':'erro','mensagem':f"Erro ao cadastrar produto {err}"}
        finally:
            cursor.close()
            conn.close()

# inserir planta deposito
def insert_plantadeposito(dados):
    conn = connect_db
    print("conexao: ", conn)
    
    if conn:
        try:
            cursor = conn.cursor()
            sql="INSERT INTO criarplanta (imagem) VALUES (%s)"
            values = ( dados['imagem'])
            print (values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':'Planta cadastrado com sucesso'}
        except mysql.connector.Error as err:
            print("erro",err)
            return {'status':'erro','mensagem':f"Erro ao cadastrar planta {err}"}
        finally:
            cursor.close()
            conn.close()

# inserir movimentacao
def insert_movimento(dados):
    conn = connect_db
    print("conexao: ", conn)
    
    if conn:
        try:
            cursor = conn.cursor()
            sql="INSERT INTO movimentacao(dados) VALUES (%s)"
            values = ( dados['dados'])
            print (values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'sucesso','mensagem':'Movimentação cadastrada com sucesso'}
        except mysql.connector.Error as err:
            print("erro",err)
            return {'status':'erro','mensagem':f"Erro ao cadastrar movimentação {err}"}
        finally:
            cursor.close()
            conn.close()
            
#pedido
def insert_cliente(pedido):
    conn = connect_db()
    if conn:
        try:
            cursor = conn.cursor()
            sql = "INSERT INTO cliente (id, valor, pagamento) VALUES (%s, %s, %s)"
            values = (pedido['id'], pedido['valor'], pedido['pagamento'])
            print(values)
            cursor.execute(sql,values)
            conn.commit()
            return{'status': 'sucesso', 'mensagem': 'pedido feito com sucesso.'}
        except mysql.connector.Error as err:
            return{'status': 'erro', 'mensagem': f"erro ao fazer pedido: {err}"}
        finally:
            cursor.close()
            conn.close() 

#notificacao


def insert_cliente(notificacao):
    conn = connect_db()
    if conn:
        try:
            cursor = conn.cursor()
            sql = "INSERT INTO cliente (id, data, sobre) VALUES (%s, %s, %s)"
            values = (notificacao['id'], notificacao['data'], notificacao['sobre'])
            print(values)
            cursor.execute(sql,values)
            conn.commit()
            return{'status': 'sucesso', 'mensagem': 'notificado com sucesso.'}
        except mysql.connector.Error as err:
            return{'status': 'erro', 'mensagem': f"erro ao emitir notificação: {err}"}
        finally:
            cursor.close()
            conn.close() 

#fornecedor
def insert_fornecedores (dados):
    conn = connect_db()
    if conn:
        try:
            cursor = conn.cursor()
            sql = "INSERT INTO fornecedor(fornecedor_cnpj,fornecedor_nome) VALUES(%s,%s)"
            values = (dados['fornecedor_cnpj'],dados['fornecedor_nome'])
            print(values)
            cursor.execute(sql,values)
            conn.commit()
            return {'status':'Sucesso','mensagem':'Fornecedor adicionado com sucesso!'}
        except mysql.connector.Error as err:
            return {'status':'Erro','mensagem':f'ocorreu um erro {err}'}
        finally:
            cursor.close()
            conn.close()